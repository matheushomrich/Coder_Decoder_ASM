# ASM Montator 2020
# Matheus Schreiner Homrich da Silva e Thiago Gomes Vidal de Mello
# Para executar nosso programa basta voce abrir o MatheusHomrich_ThiagoMello.exe e digitar o nome dos arquivos com .txt no final
# Os arquivos de entrada PRECISAM estar no mesmo diretorio que o MatheusHomrich_ThiagoMello.exe
# Os resultados estarao guardados em arquivos .asm na pasta OUTPUT que sera gerada no mesmo direitorio
# HexaToASM.asm sera o arquivo MONTADO
# ASMToHexa.asm sera o arquivo DESMONTADO 
# Lembrar de apagar a pasta OUTPUT antes de rodar novamente para que os novos arquivos criados nao sejam jogados soltos no diretorio e sim novamente na pasta OUTPUT